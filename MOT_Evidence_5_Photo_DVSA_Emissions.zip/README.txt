MOT Evidence — 5-photo DVSA emissions test build

Replace these files in the GitHub Pages repository root:
- index.html
- app.js
- sw.js

manifest.webmanifest and icon.svg are unchanged but included for completeness.

Changes:
- VIN is image-only (Photo 2): no typed VIN and no VIN verification.
- Mileage is image-only (Photo 3): no typed mileage and no comparison.
- Photo 4 adds emissions evidence with automatic DVSA-based classification using fuelType and first-use/manufacture date where supplied.
- Clear automatic categories:
  * Electric: emissions photo optional / not required.
  * Hybrid/electric-combustion: emissions photo optional / not required.
  * Fuel cell: emissions photo optional / not required.
  * Diesel/compression ignition before 1 Jan 1980: visual-only; emissions photo optional.
  * Diesel/compression ignition on/after 1 Jan 1980: smoke-test photo required.
  * Petrol/common spark ignition before 1 Aug 1975: visual-only; emissions photo optional.
  * Petrol/common spark ignition on/after 1 Aug 1975: emissions-test photo required.
  * Unknown/special fuel: manual review; Photo 4 required unless tester selects Other.
- Photo 5 adds brake-test evidence. Photo required unless tester selects Other for an approved alternative/special circumstance.
- All five photos use the same registration/date/time/GPS watermark style.
- Connections remain hidden and continue to use existing localStorage configuration.
- Drive folders are now MOT Evidence / YYYY-MM-DD / REGISTRATION (or Attempt N).
- Evidence summary records the emissions rule and tester exceptions.
- Local photos are only cleared after all selected photos and the JSON summary upload successfully.
