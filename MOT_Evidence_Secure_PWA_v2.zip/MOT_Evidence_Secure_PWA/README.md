# MOT Evidence Secure PWA v2

This package upgrades the GitHub Pages iPhone PWA to use a secure serverless backend.

## Frontend
Upload the contents of `frontend/` to the root of your existing GitHub Pages repository, replacing the old files.

After GitHub Pages updates, open the installed Home Screen app, enter your backend Worker URL once, and tap **Save backend**.

## Backend
`cloudflare-worker/worker.js` is a Cloudflare Worker that keeps API credentials off the iPhone and out of GitHub Pages.

Endpoints:
- `POST /anpr` -> NPR API number plate recognition with vehicle enrichment
- `POST /dvla` -> DVLA VES (optional)
- `GET /mot/registration/:registration` -> DVSA MOT History
- `GET /mot/vin/:vin` -> DVSA MOT History VIN cross-check
- `POST /submit` -> forwards the complete evidence package to a configured evidence destination

The Worker intentionally refuses to report a successful upload unless `EVIDENCE_UPLOAD_URL` is configured and positively responds. This preserves the app rule: local photos are deleted only after confirmed receipt.

## Required secrets
- NPR_API_KEY
- DVSA_API_KEY
- DVSA_CLIENT_ID
- DVSA_CLIENT_SECRET
- DVSA_SCOPE
- DVSA_TOKEN_URL

Optional:
- DVLA_API_KEY (DVLA currently may not accept new VES registrations)
- EVIDENCE_UPLOAD_URL
- EVIDENCE_UPLOAD_TOKEN

## Privacy/security
Do not put API keys into `app.js`, GitHub repository files, or the iPhone's local storage. Only the non-secret Worker URL is stored in the PWA.

## Note
This is a prototype and is not an official DVSA app or approved MOT submission client.
