
let tokenCache={token:null,expires:0};
const cors={
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Headers":"Content-Type, Authorization",
  "Access-Control-Allow-Methods":"GET,POST,OPTIONS"
};
const j=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"content-type":"application/json"}});
async function dvsaToken(env){
  if(tokenCache.token && Date.now()<tokenCache.expires-60000)return tokenCache.token;
  if(!env.DVSA_TOKEN_URL||!env.DVSA_CLIENT_ID||!env.DVSA_CLIENT_SECRET||!env.DVSA_SCOPE)throw new Error("DVSA credentials are not configured");
  const body=new URLSearchParams({grant_type:"client_credentials",client_id:env.DVSA_CLIENT_ID,client_secret:env.DVSA_CLIENT_SECRET,scope:env.DVSA_SCOPE});
  const r=await fetch(env.DVSA_TOKEN_URL,{method:"POST",headers:{"content-type":"application/x-www-form-urlencoded"},body});
  if(!r.ok)throw new Error("DVSA token request failed");
  const x=await r.json();tokenCache={token:x.access_token,expires:Date.now()+((x.expires_in||1200)*1000)};return x.access_token;
}
async function dvsaGet(env,path){
  const tok=await dvsaToken(env);
  const r=await fetch(`https://history.mot.api.gov.uk${path}`,{headers:{Authorization:`Bearer ${tok}`,"X-API-Key":env.DVSA_API_KEY}});
  const t=await r.text();let x;try{x=JSON.parse(t)}catch{x={message:t}};if(!r.ok)throw new Error(x.message||`DVSA error ${r.status}`);return x;
}
export default {
 async fetch(req,env){
  if(req.method==="OPTIONS")return new Response(null,{headers:cors});
  const u=new URL(req.url);
  try{
   if(u.pathname==="/health")return j({ok:true});
   if(u.pathname==="/anpr"&&req.method==="POST"){
     if(!env.NPR_API_KEY)return j({error:"NPR_API_KEY not configured"},503);
     const incoming=await req.formData(), image=incoming.get("image");if(!image)return j({error:"image is required"},400);
     const fd=new FormData();fd.append("image",image,"plate.jpg");fd.append("vehicle","true");
     const r=await fetch("https://nprapi.com/api/v1/recognise",{method:"POST",headers:{"X-API-Key":env.NPR_API_KEY},body:fd});
     const x=await r.json();return j(x,r.status);
   }
   if(u.pathname==="/dvla"&&req.method==="POST"){
     if(!env.DVLA_API_KEY)return j({error:"DVLA_API_KEY not configured"},503);
     const {registrationNumber}=await req.json();
     const r=await fetch("https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles",{method:"POST",headers:{"content-type":"application/json","x-api-key":env.DVLA_API_KEY},body:JSON.stringify({registrationNumber:String(registrationNumber||"").replace(/[^A-Za-z0-9]/g,"")})});
     const x=await r.json();return j(x,r.status);
   }
   let m=u.pathname.match(/^\/mot\/registration\/([^/]+)$/);
   if(m&&req.method==="GET")return j(await dvsaGet(env,`/v1/trade/vehicles/registration/${encodeURIComponent(m[1])}`));
   m=u.pathname.match(/^\/mot\/vin\/([^/]+)$/);
   if(m&&req.method==="GET")return j(await dvsaGet(env,`/v1/trade/vehicles/vin/${encodeURIComponent(m[1])}`));
   if(u.pathname==="/submit"&&req.method==="POST"){
     if(!env.EVIDENCE_UPLOAD_URL)return j({error:"Evidence destination is not configured; refusing to fake a successful upload."},503);
     const form=await req.formData();
     const r=await fetch(env.EVIDENCE_UPLOAD_URL,{method:"POST",body:form,headers:env.EVIDENCE_UPLOAD_TOKEN?{"Authorization":`Bearer ${env.EVIDENCE_UPLOAD_TOKEN}`}:{}}); 
     if(!r.ok)return j({error:`Evidence destination returned ${r.status}`},502);
     const x=await r.json().catch(()=>({}));
     return j({confirmed:true,reference:x.reference||x.id||crypto.randomUUID()});
   }
   return j({error:"Not found"},404);
  }catch(e){return j({error:e.message||"Unexpected error"},500)}
 }
}
